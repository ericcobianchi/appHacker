import { Component } from '@angular/core';
import { IonicPage, NavController, ToastController, AlertController } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HackerProxie } from '../../proxie/hacker';
import { PersonagemProvider } from '../../providers/personagem/personagem';
import { HomePage } from '../home/home';
import { ImagemProvider } from '../../providers/imagem/imagem';
import { Camera, CameraOptions} from '@ionic-native/camera';



@IonicPage()
@Component({
  selector: 'page-cadastro',
  templateUrl: 'cadastro.html',
})
export class CadastroPage {
  form: FormGroup;
  hackerProxie: HackerProxie;
  foto = '';
  fotoHacker;

  constructor(
    public navCtrl: NavController,
    public toastCtrl: ToastController,
    private formBuilder: FormBuilder,
    private personagemProvider: PersonagemProvider,
    private alertCtrl: AlertController,
    private imagemProvider: ImagemProvider,
    private _camera: Camera,

  )
  {
    this.form = formBuilder.group({
      nome:["",[Validators.required, Validators.minLength(3)]],
      sobrenome:["",[Validators.required, Validators.minLength(3)]],
      motivo:["",[Validators.required, Validators.minLength(4)]],
      pena:["",[Validators.required, Validators.minLength(2)]],
      atualmente:["",[Validators.required, Validators.minLength(1)]]
    })
  }

  async cadastrar() {
    if (this.form.valid) {
      let personagemCadastro: HackerProxie = { ...this.form.value };
      try {
        let data = await this.personagemProvider.create(personagemCadastro)
        console.log(data);
        this.mostrarToast('Cadastrado com sucesso');
        this.navCtrl.setRoot(HomePage)
      } catch (erro) {
        this.mostrarAlert('Erro ao cadastrar!');
      }
    } else {
      this.mostrarToast('Campos em branco!')
    }
  }

  buscarImagem() {
    const options: CameraOptions = {
      quality: 100,
      destinationType: this._camera.DestinationType.DATA_URL,
      sourceType: this._camera.PictureSourceType.PHOTOLIBRARY,
      saveToPhotoAlbum: false,
      allowEdit: true,
      targetWidth: 200,
      targetHeight: 200
    }
    this._camera.getPicture(options).then((imageData) => {
      let foto = 'data:image/jpeg;base64,' + imageData;
      this.foto = foto;
    }, (err) => {
      console.log(err);
    });
  }

  deleteFile(file) {
    this.imagemProvider.deleteFile(file).subscribe(() => {
      this.mostrarToast("Imagem removida com sucesso!")
    })
  }

  mostrarToast(mensagem: string) {
    let toast = this.toastCtrl.create({
      message: mensagem,
      duration: 500,
      position: "top"
    })
    toast.present();
  }

  mostrarAlert(mensagem: string) {
    this.alertCtrl.create({
      title: 'Aviso',
      subTitle: mensagem,
      buttons: ['OK']
    })
      .present();
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad CadastroPage');
  }

}
