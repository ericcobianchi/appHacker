export class HackerProxie {
  key: string;
  nome: string;
  sobrenome: string;
  motivo: string;
  pena: string;
  atualmente: string;
  imagem:string;
}
